此文件放到 `~/.local/share/`直接覆盖掉fcitx5这个文件夹就可以. 

